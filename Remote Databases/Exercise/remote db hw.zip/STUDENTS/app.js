const loadBtn = document.querySelector('#loadBtn');
const submitBtn = document.querySelector('#submitBtn');

const firstNameInput = document.querySelector('#firstName');
const lastNameInput = document.querySelector('#lastName');
const facultyNumInput = document.querySelector('#facultyNumber');
const gradeInput = document.querySelector('#grade');

const results = document.querySelector('#results > tbody');

const api = {
    students: 'https://api.backendless.com/4229B568-2E3F-C9A8-FF84-86BEA0A6D900/CBBD887A-327F-436C-9B0B-6F48E52CF24E/data/students'
};

window.addEventListener('load', () => {
    loadBtn.addEventListener('click', getAllStudents);
    submitBtn.addEventListener('click', addStudent);

    async function getStudentsCount() {
        const response = await fetch(api.students);
        const students = await response.json();

        return [...students].length;
    }

    async function getAllStudents() {
        results.innerHTML = '';

        const response = await fetch(api.students);
        const students = await response.json();

        const sortedStudents = [...students].sort((a, b) => a.ID - b.ID);

        sortedStudents.forEach(student => {
            const studentRow = document.createElement('tr');
            const studentIdCell = document.createElement('td');
            const firstNameCell = document.createElement('td');
            const lastNameCell = document.createElement('td');
            const facultyNumberCell = document.createElement('td');;
            const gradeCell = document.createElement('td');

            studentIdCell.innerHTML = student.ID;
            firstNameCell.innerHTML = student.FirstName;
            lastNameCell.innerHTML = student.LastName;
            facultyNumberCell.innerHTML = student.FacultyNumber;
            gradeCell.innerHTML = Number(student.Grade).toFixed(2);

            studentRow.appendChild(studentIdCell);
            studentRow.appendChild(firstNameCell);
            studentRow.appendChild(lastNameCell);
            studentRow.appendChild(facultyNumberCell);
            studentRow.appendChild(gradeCell);

            results.appendChild(studentRow);
        });
    }

    async function addStudent(e) {
        e.preventDefault();

        const count = await getStudentsCount();
        const id = count + 1;

        const studentObj = {
            ID: id,
            FirstName: firstNameInput.value,
            lastName: lastNameInput.value,
            FacultyNumber: facultyNumInput.value,
            Grade: Number(gradeInput.value)
        };

        firstNameInput.value = '';
        lastNameInput.value = '';
        facultyNumInput.value = '';
        gradeInput.value = '';

        const requestObj = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(studentObj)
        };

        await fetch(api.students, requestObj);
        await getAllStudents();
    }
});