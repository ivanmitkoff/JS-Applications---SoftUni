const appId = '4229B568-2E3F-C9A8-FF84-86BEA0A6D900';
const apiKey = 'CBBD887A-327F-436C-9B0B-6F48E52CF24E';

function host(endpoint) {
    return `https://api.backendless.com/${appId}/${apiKey}/data/${endpoint}`;
}

export async function listAllBooks() {
    const response = await fetch(host('books'));
    const body = await response.json();
    return body;

    /*Same as chaining promises:
    return fetch(host('books'))
    .then(response => response.json());
    */
}

export async function createABook(book) {
    const response = await fetch(host('books'), {
        method: 'POST',
        body: JSON.stringify(book),
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const data = await response.json();
    return data;
}

export async function updateABook(book) {
    const bookId = book.objectId;
    const response = await fetch(host('books/' + bookId), {
        method: 'PUT',
        body: JSON.stringify(book),
        headers: {
            'Content-Type': 'application/json'
        }
    });
    const data = response.json();
    return data;

}

export async function deleteABook(bookId) {
    const response = await fetch(host('books/' + bookId), {
        method: 'DELETE',
    });
    const data = await response.json();
    return data;
}